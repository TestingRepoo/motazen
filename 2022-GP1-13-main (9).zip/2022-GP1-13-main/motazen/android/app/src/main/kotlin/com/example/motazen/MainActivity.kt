package com.example.motazen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
